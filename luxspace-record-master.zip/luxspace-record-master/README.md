# The Idea

Basic boilerplate to get started slicing so you don't need to think about configuration.


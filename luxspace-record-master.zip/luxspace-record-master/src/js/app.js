import "../css/app.css";

import "./menu-toggler";
import "./modal";
import "./anchor-link-smooth";
import "./carousel";
import "./accordion";
import "./slider";
import "./shoppingCart";
import "./shippingDetail";
